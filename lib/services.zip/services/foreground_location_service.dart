import "dart:async";
import "dart:ui";

import "package:flutter_background_service/flutter_background_service.dart";
import 'package:geolocator/geolocator.dart';
import "package:flutter_local_notifications/flutter_local_notifications.dart";
import "package:vieiros/resources/i18n.dart";

class ForegroundLocationService {
  final _notificationChannelId = 'vieiros_location_service';
  final _notificationId = 873112601;
  final _service = FlutterBackgroundService();

  FlutterBackgroundService get instance => _service;

  Future<void> initializeService() async {
    final AndroidNotificationChannel channel = AndroidNotificationChannel(_notificationChannelId, I18n.translate('map_notification_title'),
        description: I18n.translate('map_notification_desc'), importance: Importance.low, enableVibration: true);

    final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

    await flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestPermission();

    await flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    await _service.configure(
        androidConfiguration: AndroidConfiguration(
          onStart: onStart,
          autoStart: false,
          isForegroundMode: true,
          notificationChannelId: _notificationChannelId,
          initialNotificationTitle: I18n.translate('map_notification_title'),
          initialNotificationContent: I18n.translate('map_notification_desc'),
          foregroundServiceNotificationId: _notificationId,
        ),
        iosConfiguration: IosConfiguration(autoStart: false, onForeground: onStart));
  }

  @pragma('vm:entry-point')
  static Future<void> onStart(ServiceInstance service) async {
    DartPluginRegistrant.ensureInitialized();

    Timer.periodic(const Duration(milliseconds: 2000), (timer) async {
      Geolocator.getPositionStream(locationSettings: AndroidSettings(foregroundNotificationConfig: const ForegroundNotificationConfig(notificationText: 'a', notificationTitle: 'a'))).listen((position) {
        print('##################################################Location sent!!');
        service.invoke('on_location_changed', position.toJson());
      });
    });

    service.on("stop_service").listen((event) async {
      await service.stopSelf();
    });
  }

  void stopService() {
    _service.invoke("stop_service");
  }

  ForegroundLocationService._privateConstructor();

  static final ForegroundLocationService _instance = ForegroundLocationService._privateConstructor();

  factory ForegroundLocationService() {
    return _instance;
  }
}
